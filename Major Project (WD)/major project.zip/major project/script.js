document.addEventListener("DOMContentLoaded", function() {
    const products = [
        { id: 1, name: "Red Short Skirt", price: 700.00, image: "dress.jpg", description: "A chic and stylish red short skirt perfect for casual outings or a night out. Its vibrant color and flattering fit make it a must-have addition to your wardrobe." },
        { id: 2, name: "Beautiful Perl earing", price: 50.00, image: "earing.jpg", description: "Elegant and timeless, these beautiful pearl earrings add a touch of sophistication to any outfit. Perfect for both everyday wear and special occasions." },
        { id: 3, name: "Mens Causal Tshirt", price: 600.00, image: "Tshirt.jpg", description: "This men's casual shirt offers a perfect blend of comfort and style. Its versatile design makes it ideal for both casual and semi-formal settings.        " },
        { id: 4, name: "Blue Steel watch", price: 1200.00, image: "watch.jpg", description: "A sleek and modern blue steel watch that combines functionality with fashion. Its durable build and stylish design make it an excellent accessory for any look." },
        { id: 5, name: "Brown Corgo Pant", price: 750.00, image: "jeans.jpg", description: "These brown cargo pants are both practical and trendy. With multiple pockets and a comfortable fit, they are perfect for outdoor activities or a casual day out." },
        { id: 6, name: "Womens Party Wear", price: 700.00, image: "sandals.jpg", description: "Elegant and sophisticated, these heels are perfect for adding a touch of class to any outfit. Whether you're heading to a formal event or a night out, these heels provide both style and comfort" },
        { id: 7, name: "Mens Formal Shirt", price: 600.00, image: "shirt.jpg", description: "This formal shirt combines classic style with modern elegance. Ideal for professional settings or formal occasions, it offers a polished look and a comfortable fit." },
        { id: 8, name: "Girls Top Wear", price: 400.00, image: "top.jpg", description: "Trendy and comfortable, this top wear for girls is perfect for everyday fashion. Its stylish design and vibrant colors make it a great addition to any young fashionista's wardrobe." },
        { id: 9, name: "Unisex Funky Shoes", price: 999.00, image: "shoes.jpg", description: " Stand out with these funky shoes that bring a burst of color and creativity to your footwear collection. Perfect for making a bold fashion statement and adding a fun twist to your casual outfits." }
    
    ];  
    let currentProduct = null;
    const orders = [];

    function viewProduct(id) {
        const product = products.find(p => p.id === id);
        currentProduct = product;
        const productDetails = document.getElementById("product-details");
        productDetails.innerHTML = `
            <h3>${product.name}</h3>
            <img src="${product.image}" alt="${product.name}">
            <p>Price: Rs${product.price.toFixed(2)}</p>
            <p>${product.description}</p>
        `;
        document.getElementById("product-modal").style.display = "block";
    }

    window.viewProduct = viewProduct;

    window.closeModal = function() {
        document.getElementById("product-modal").style.display = "none";
        currentProduct = null;
    };

    window.onclick = function(event) {
        const modal = document.getElementById("product-modal");
        if (event.target === modal) {
            modal.style.display = "none";
            currentProduct = null;
        }
    };

    document.getElementById("orderButton").addEventListener("click", function() {
        if (currentProduct) {
            orders.push(currentProduct);
            renderOrders();
            closeModal();
        }
    });

    function renderOrders() {
        const orderList = document.querySelector(".order-list");
        orderList.innerHTML = "";
        orders.forEach(order => {
            const orderItem = document.createElement("div");
            orderItem.className = "order-item";
            orderItem.innerHTML = `
                <img src="${order.image}" alt="${order.name}">
                <h3>${order.name}</h3>
                <p>Price: Rs${order.price.toFixed(2)}</p>
            `;
            orderList.appendChild(orderItem);
        });
    }
});
    