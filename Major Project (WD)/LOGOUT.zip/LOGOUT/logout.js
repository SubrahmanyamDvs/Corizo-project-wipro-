

document.addEventListener('DOMContentLoaded', 
    function() {
    var logoutBtn = document.getElementById('logoutBtn');

    logoutBtn.addEventListener('click', function() {
        alert('You have been logged out.');

        window.location.href = ''  //here add the login form link;
    });
});
