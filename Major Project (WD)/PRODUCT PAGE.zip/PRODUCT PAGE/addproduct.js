let selectedRow = null;

document.addEventListener('DOMContentLoaded', loadFormData);

function loadFormData() {
    const editMode = localStorage.getItem('editMode') === 'true';
    if (editMode) {
        document.getElementById("formTitle").innerText = "Edit Product";
        document.getElementById("submitButton").innerText = "Update Product";

        const product = JSON.parse(localStorage.getItem('productToEdit'));
        document.getElementById("editMode").value = "true";
        document.getElementById("editIndex").value = product.index;
        document.getElementById("productName").value = product.productName;
        document.getElementById("productDescription").value = product.productDescription;
        document.getElementById("productPrice").value = product.productPrice;
        document.getElementById("productSize").value = product.productSize;
        document.getElementById("productImage").value = product.productImage;
    }
}

function onFormSubmit(event) {
    event.preventDefault();
    const formData = readFormData();
    const editMode = document.getElementById("editMode").value === 'true';

    if (editMode) {
        updateRecord(formData);
    } else {
        storeFormData(formData);
    }
    resetForm();
    window.location.href = 'productlist.html'; 
}

function readFormData() {
    const formData = {};
    formData["productName"] = document.getElementById("productName").value;
    formData["productDescription"] = document.getElementById("productDescription").value;
    formData["productPrice"] = document.getElementById("productPrice").value;
    formData["productSize"] = document.getElementById("productSize").value;
    formData["productImage"] = document.getElementById("productImage").value;
    formData["index"] = document.getElementById("editIndex").value;
    return formData;
}

function storeFormData(data) {
    let products = JSON.parse(localStorage.getItem('products')) || [];
    products.push(data);
    localStorage.setItem('products', JSON.stringify(products));
}

function updateRecord(formData) {
    let products = JSON.parse(localStorage.getItem('products')) || [];
    products[formData.index] = formData;
    localStorage.setItem('products', JSON.stringify(products));
}

function resetForm() {
    document.getElementById("productName").value = "";
    document.getElementById("productDescription").value = "";
    document.getElementById("productPrice").value = "";
    document.getElementById("productSize").value = "";
    document.getElementById("productImage").value = "";
    document.getElementById("editMode").value = "false";
    document.getElementById("editIndex").value = "-1";
    localStorage.removeItem('editMode');
    localStorage.removeItem('productToEdit');
}
