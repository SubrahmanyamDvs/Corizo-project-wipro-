document.addEventListener('DOMContentLoaded', loadProductData);

function loadProductData() {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    products.forEach((product, index) => {
        product.index = index;
        insertNewRecord(product);
    });
}

function insertNewRecord(data) {
    const table = document.getElementById("productlist").getElementsByTagName('tbody')[0];
    const newRow = table.insertRow(table.rows.length);
    let cell1 = newRow.insertCell(0);
    cell1.innerHTML = data.productName;
    let cell2 = newRow.insertCell(1);
    cell2.innerHTML = data.productDescription;
    let cell3 = newRow.insertCell(2);
    cell3.innerHTML = data.productPrice;
    let cell4 = newRow.insertCell(3);
    cell4.innerHTML = data.productSize;
    let cell5 = newRow.insertCell(4);
    const img = document.createElement('img');
    img.src = data.productImage;
    img.alt = data.productName;
    img.style.width = '100px';
    img.style.height = 'auto';
    cell5.appendChild(img);
    let cell6 = newRow.insertCell(5);
    cell6.innerHTML = `<button onclick="onEdit(${data.index})">Edit</button>
                       <button onclick="onDelete(this)">Delete</button>`;
}

function onEdit(index) {
    const products = JSON.parse(localStorage.getItem('products')) || [];
    const product = products[index];
    product.index = index; 
    localStorage.setItem('editMode', 'true');
    localStorage.setItem('productToEdit', JSON.stringify(product));
    window.location.href = 'addproduct.html';
}

function onDelete(td) {
    if (confirm('Are you sure to delete this record?')) {
        const row = td.parentElement.parentElement;
        document.getElementById("productlist").deleteRow(row.rowIndex);
        let products = JSON.parse(localStorage.getItem('products')) || [];
        products.splice(row.rowIndex - 1, 1);
        localStorage.setItem('products', JSON.stringify(products));
    }
}
