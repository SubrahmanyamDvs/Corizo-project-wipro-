// Dummy product data
const products = [
    {
        id: 1,
        name: "Product 1",
        description: "Description for product 1.",
        price: "$10.00",
        image: "product1.jpg"
    },
    {
        id: 2,
        name: "Product 2",
        description: "Description for product 2.",
        price: "$20.00",
        image: "product2.jpg"
    },
    {
        id: 3,
        name: "Product 3",
        description: "Description for product 3.",
        price: "$30.00",
        image: "product3.jpg"
    },
    // Add more products as needed
];

// Function to render products
function displayProducts() {
    const productGrid = document.getElementById('productGrid');
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.description}</p>
            <p>${product.price}</p>
            <button>Add to Cart</button>
        `;
        productGrid.appendChild(productCard);
    });
}

// Execute displayProducts on page load
window.onload = displayProducts;
