document.getElementById('registrationForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form from submitting traditionally
    
    // Get form values
    const username = document.getElementById('username').value.trim();
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value.trim();

    // Clear previous messages
    const errorContainer = document.getElementById('error');
    const successContainer = document.getElementById('success');
    errorContainer.style.display = 'none';
    successContainer.style.display = 'none';
    
    // Simple validation
    if (!username || !email || !password) {
        errorContainer.textContent = 'All fields are required.';
        errorContainer.style.display = 'block';
        return;
    }
    
    if (!validateEmail(email)) {
        errorContainer.textContent = 'Invalid email format.';
        errorContainer.style.display = 'block';
        return;
    }

    // Simulate success - in a real scenario, you'd handle backend communication here
    successContainer.textContent = 'Registration successful!';
    successContainer.style.display = 'block';

    // Redirect to login page after a short delay
    setTimeout(() => {
        window.location.href = 'login.html';
    }, 2000); // Adjust the delay as needed
});

// Email validation function
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}
