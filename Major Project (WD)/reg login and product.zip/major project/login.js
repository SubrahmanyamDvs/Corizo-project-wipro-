document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');

    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission behavior

            // Redirect to product page after successful login
            alert('Login successful! Redirecting to product page.');
            setTimeout(() => {
                window.location.href = 'product.html';
            }, 2000); // Redirect after 2 seconds (2000 milliseconds)
        });
    }
});
