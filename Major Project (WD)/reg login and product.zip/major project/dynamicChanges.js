// Function to change background image
function changeBackground(imageUrl) {
    document.body.style.backgroundImage = `url(${imageUrl})`;
}

// Function to change product images dynamically
function changeProductImage(productId, newImageUrl) {
    const productCard = document.querySelector(`.product-card[data-id="${productId}"] img`);
    if (productCard) {
        productCard.src = newImageUrl;
    }
}

// Example usage:
// Uncomment the lines below to test the dynamic changes.
// changeBackground('images/new-background.jpg');
// changeProductImage(1, 'images/new-product1.jpg');
