document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginForm) {
        loginForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const errorMessage = document.getElementById('error-message');
 
            
            const storedEmail = localStorage.getItem('email');
            const storedPassword = localStorage.getItem('password');


            if (email === storedEmail && password === storedPassword) {
                alert('Login successful!');
                window.location.href = 'admin-dashboard.html';
            } else {
                errorMessage.textContent = 'Invalid email or password';
                errorMessage.style.display = 'block';
            }
        });
    }

    if (registerForm) {
        registerForm.addEventListener('submit', function(event) {
            event.preventDefault();

            const username = document.getElementById('registerUsername').value;
            const email = document.getElementById('registerEmail').value;
            const password = document.getElementById('registerPassword').value;
            const registerError = document.getElementById('registerError');

            if (localStorage.getItem('username') === username) {
                registerError.textContent = 'Username already exists';
                registerError.style.display = 'block';
            } else {
                localStorage.setItem('username', username);
                localStorage.setItem('email', email);
                localStorage.setItem('password', password);

                alert('Registration successful!');
                window.location.href = 'login.html';
            }
        });
    }
});




