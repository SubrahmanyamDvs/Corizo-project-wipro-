document.addEventListener("DOMContentLoaded", () => {
    const content = document.getElementById("content"); 

    document.getElementById("add-products").addEventListener("click", () => {
        content.innerHTML = `
            <h2>Add Products</h2>
            <p>Product list are displaying here.</p>
        `;
        // You can add add product functionality here
    });

    document.getElementById("view-customers").addEventListener("click", () => {
        content.innerHTML = `
            <h2>View Customers</h2>
            <p>Customer list are displaying here.</p>
        `;
        // You can add view customer functionality here
    });

    document.getElementById("view-orders").addEventListener("click", () => {
        content.innerHTML = `
            <h2>View Orders</h2>
            <p>Order lists are displaying here.</p>
        `;
        // You can add view order functionality here
    });

    document.getElementById("logout").addEventListener("click", () => {
        // You can add logout functionality here

    });
});
