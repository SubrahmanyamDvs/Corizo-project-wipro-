document.addEventListener('DOMContentLoaded', function() {
    var ordersList = document.getElementById('ordersList');
    var orders = []; 

    function displayOrders() {
        ordersList.innerHTML = '';

        orders.forEach(function(order) {
            var orderDiv = document.createElement('div');
            orderDiv.classList.add('order');

            var orderDetails = document.createElement('div');
            orderDetails.classList.add('order-details');
            orderDetails.innerHTML = '<span class="order-id">Order ID: ' + order.id + '</span>' +
                                     '<span class="order-status">Status: ' + order.status + '</span>';
            orderDiv.appendChild(orderDetails);

            var orderItems = document.createElement('div');
            orderItems.classList.add('order-items');
            order.items.forEach(function(item) {
                var itemDiv = document.createElement('div');
                itemDiv.classList.add('order-item');

                
                var itemImage = document.createElement('img');
                itemImage.src = item.image; 
                itemImage.alt = item.name; 
                itemImage.classList.add('order-item-image');
                itemDiv.appendChild(itemImage);

                var itemText = document.createElement('span');
                itemText.textContent = item.name +' , '+item.size +' , '+ ' Rs-' + item.price;
                itemDiv.appendChild(itemText);

                orderItems.appendChild(itemDiv);
            });
            orderDiv.appendChild(orderItems);
            

            var orderTotal = document.createElement('div');
            orderTotal.classList.add('order-total');
            orderTotal.textContent = 'Total: Rs' + order.total;
            orderDiv.appendChild(orderTotal);

            ordersList.appendChild(orderDiv);
        });
    }

    function addOrder(order) {
        orders.push(order);
        displayOrders();
    }

    //orders being added (when users place orders)
    addOrder({
        id: '1594',
        status: 'Processing',
        items: [
            {name: 'TShirt',size:'M', price: 399.99 , image: 'Tshirt.jpg'},
            { name: 'Jeans', size:'L',price: 700 ,image: 'jeans.jpg'},
            { name: 'Shoes', size:'46',price: 950 ,image: 'shoes.jpg'}
        ],
        total: 2648.99
    });

    addOrder({
        id: '1578',
        status: 'Delivered',
        items: [
            { name: 'Dress', size:'M',price: 600, image: 'dress.jpg' },
            { name: 'Sandals',size:'M', price:800.65, image: 'sandals.jpg' }
        ],
        total: 1400.65
    });


    addOrder({
        id: '3546',
        status: 'Delivered',
        items: [
            { name: 'Shirt', size:'M',price: 599,image: 'shirt.jpg' },
            { name: 'Watch', size:'M', price: 4600, image: 'watch.jpg' }
        ],
        total: 4600.00
    });
    
    
    addOrder({
        id: '8465',
        status: 'Processing',
        items: [
            { name: 'Top', size:'M',price: 299,image: 'top.jpg' },
            { name: 'Earing', size:'free size', price: 60, image: 'earing.jpg' }
        ],
        total: 4600.00
    });
    
});
